/**
 * ${NAME}
 *
 * @copyright Copyright © ${YEAR} ${company}. All rights reserved.
 * @author    ${userEmail}
 */