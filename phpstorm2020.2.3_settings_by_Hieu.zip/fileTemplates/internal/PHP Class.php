<?php
#parse("stmpfl_variables.txt")
#parse("stmpfl_header_php.php")

#if (${NAMESPACE})

namespace ${NAMESPACE};

#end

class ${NAME} {

}